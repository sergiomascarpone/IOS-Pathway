//
//  iOSPathwayApp.swift
//  IOS Pathway
//
//  Created by Sergio Mascarpone on 12.02.25.
//

import SwiftUI

@main
struct iOSPathwayApp: App {
    var body: some Scene {
        WindowGroup {
            WelcomeView()
        }
    }
}
