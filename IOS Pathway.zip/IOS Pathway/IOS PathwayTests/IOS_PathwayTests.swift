//
//  IOS_PathwayTests.swift
//  IOS PathwayTests
//
//  Created by Sergio Mascarpone on 12.02.25.
//

import Testing
@testable import IOS_Pathway

struct IOS_PathwayTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
